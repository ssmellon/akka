package com.karl.pre;

import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.actor.ActorSystem;
import akka.actor.Props;
import com.karl.pre.actor.ClusterController;
import com.karl.pre.message.ClusterMessage;

public class ClusterMain
{
    public static void main(String[] args)
    {
        ActorSystem actorSystem = ActorSystem.create("ClusterSystem");
        ActorRef clusterController = actorSystem.actorOf(Props.create(ClusterController.class),
                "clusterController");

        clusterController.tell(new ClusterMessage("id"), ActorRef.noSender());

        final String path = "akka.tcp://ClusterSystem@127.0.0.1:2555/user/clusterController";
        final ActorSelection destination = actorSystem.actorSelection(path);
//        final ActorRef myPersistentActor = actorSystem.actorOf(destination);
        destination.tell(new ClusterMessage("id"), ActorRef.noSender());

    }
}

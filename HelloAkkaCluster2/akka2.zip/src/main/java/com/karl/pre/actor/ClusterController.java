package com.karl.pre.actor;
import akka.actor.AbstractActor;
import akka.cluster.Cluster;
import static akka.cluster.ClusterEvent.*;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import com.karl.pre.message.ClusterMessage;

public class ClusterController extends AbstractActor
{
    private final LoggingAdapter log = Logging.getLogger(context().system(), this);

    private Cluster cluster = Cluster.get(getContext().system());

    @Override
    public void preStart()
    {
        cluster.subscribe(self(), initialStateAsEvents(),
                MemberEvent.class, UnreachableMember.class);
    }

    @Override
    public void postStop()
    {
        cluster.unsubscribe(self());
    }


    @Override
    public Receive createReceive()
    {
        return receiveBuilder()
                .match(MemberEvent.class, message -> {
                    log.info("MemberEvent: {}", message);
                })
                .match(UnreachableMember.class, message -> {
                            log.info("UnreachableMember: {}", message);
                        }
                )
                .match(ClusterMessage.class, message -> {
                            log.info("ClusterMessage -2------------------- : {}", message);
                        }
                )
                .build();
    }

}
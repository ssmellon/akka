package com.karl.pre;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import com.karl.pre.actor.ClusterController;

public class ClusterMain
{
    public static void main(String[] args)
    {
        ActorSystem system = ActorSystem.create("ClusterSystem");
        ActorRef clusterController = system.actorOf(Props.create(ClusterController.class),
                "clusterController");
    }
}
